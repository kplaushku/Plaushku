from .visual import PlaushkuKeywords

__all__ = ["PlaushkuKeywords"]